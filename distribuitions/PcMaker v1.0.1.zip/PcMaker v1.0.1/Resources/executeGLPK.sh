cd Resources/
./solver/glpsol --model pcmaker.mod --data pcmaker.dat > output.out



